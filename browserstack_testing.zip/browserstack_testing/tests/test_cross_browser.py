
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.remote_connection import RemoteConnection
import time

# BrowserStack credentials (replace with your credentials if running this)
USERNAME = 'YOUR_USERNAME'
ACCESS_KEY = 'YOUR_ACCESS_KEY'

desired_cap = {
    'os': 'Windows',
    'os_version': '10',
    'browser': 'Chrome',
    'browser_version': 'latest',
    'name': 'Cross-browser test on saucedemo.com',
    'build': 'browserstack-build-1'
}

# Remote WebDriver URL for BrowserStack
url = f"http://{USERNAME}:{ACCESS_KEY}@hub-cloud.browserstack.com/wd/hub"

driver = webdriver.Remote(
    command_executor=url,
    desired_capabilities=desired_cap
)

try:
    driver.get("https://www.saucedemo.com/")
    time.sleep(2)

    # Perform login test
    driver.find_element(By.ID, "user-name").send_keys("standard_user")
    driver.find_element(By.ID, "password").send_keys("secret_sauce")
    driver.find_element(By.ID, "login-button").click()
    time.sleep(3)

    # Capture screenshot after login
    driver.save_screenshot("screenshot_after_login.png")

    # Validate URL to confirm login success
    if "inventory.html" in driver.current_url:
        print("Login test passed.")
    else:
        print("Login test failed.")

finally:
    driver.quit()
