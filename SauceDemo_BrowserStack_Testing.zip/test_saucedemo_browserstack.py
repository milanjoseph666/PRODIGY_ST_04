
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# BrowserStack credentials (replace with your own)
BROWSERSTACK_USERNAME = 'your_username'
BROWSERSTACK_ACCESS_KEY = 'your_access_key'

desired_cap = {
    'os': 'Windows',
    'os_version': '10',
    'browser': 'Chrome',
    'browser_version': 'latest',
    'name': 'CrossBrowserTest_SauceDemo',
    'build': 'browserstack-build-1'
}

driver = webdriver.Remote(
    command_executor=f'https://{BROWSERSTACK_USERNAME}:{BROWSERSTACK_ACCESS_KEY}@hub-cloud.browserstack.com/wd/hub',
    desired_capabilities=desired_cap
)

driver.get("https://www.saucedemo.com/")
driver.find_element(By.ID, "user-name").send_keys("standard_user")
driver.find_element(By.ID, "password").send_keys("secret_sauce")
driver.find_element(By.ID, "login-button").click()
time.sleep(5)

# Assertion and screenshots can be added as needed
assert "inventory" in driver.current_url

driver.quit()
