
# SauceDemo Cross-Browser Testing with BrowserStack

## Requirements
- BrowserStack Account (https://www.browserstack.com/)
- Selenium Library (`pip install selenium`)

## Setup
1. Replace `your_username` and `your_access_key` in the script with your BrowserStack credentials.
2. Run the script to test login on SauceDemo across Chrome (Windows 10).

## Browsers You Can Test
- Chrome
- Firefox
- Safari
- Edge

## Run the Script
```bash
python test_saucedemo_browserstack.py
```

## Observations (Example)
- ✅ Chrome, Firefox: Login successful, no issues.
- ⚠️ Safari: Slight layout shift on login screen.
- ✅ Edge: All functionalities working as expected.
