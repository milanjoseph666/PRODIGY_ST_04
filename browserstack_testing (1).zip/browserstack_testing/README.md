
# Cross-Browser Testing with BrowserStack

## Demo Site:
https://www.saucedemo.com/

## Test Objective:
To perform cross-browser testing of the login functionality on the saucedemo site using BrowserStack.

## Browsers Tested:
- Chrome (Windows 10)
- Firefox (Windows 10)
- Safari (macOS Big Sur)
- Edge (Windows 10)

## Steps Performed:
1. Open the saucedemo.com login page.
2. Enter username: `standard_user`
3. Enter password: `secret_sauce`
4. Click the login button.
5. Validate if the user is redirected to the inventory page.

## Observations:

| Browser  | Result           | Notes                                                   |
|----------|------------------|---------------------------------------------------------|
| Chrome   | ✅ Passed         | Login successful, redirected to inventory.html         |
| Firefox  | ✅ Passed         | Login successful, no layout issues observed            |
| Safari   | ✅ Passed         | Login successful, slightly slower page load            |
| Edge     | ✅ Passed         | Login successful, layout consistent with Chrome        |

## Conclusion:
All browsers successfully passed the login test. No major inconsistencies were observed.

## Notes:
Ensure your BrowserStack credentials are correctly set in the script before running.
